package com.example.projetoenem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Home extends AppCompatActivity {

//    BottomNavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

//        navigationView = findViewById(R.id.bottom_navegation);
//        getSupportFragmentManager().beginTransaction().replace(R.id.body, new CasaFragment()).commit();
//        navigationView.setSelectedItemId(R.id.nav_casa);
//
//        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                Fragment fragment = null;
//                switch (item.getItemId()){
//                    case R.id.nav_casa:
//                        fragment = new CasaFragment();
//                        break;
//
//                    case R.id.nav_lupa:
//                        fragment = new LupaFragment();
//                        break;
//
//                    case R.id.nav_comentarios:
//                        fragment = new ComentariosFragment();
//                        break;
//
//                    case R.id.nav_shop:
//                        fragment = new ShopFragment();
//                        break;
//                }
//                getSupportFragmentManager().beginTransaction().replace(R.id.body,fragment).commit();
//
//                return true;
//            }
//        });
    }
}